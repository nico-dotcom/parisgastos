import DashboardClient from '@/components/dashboard/dashboard-client'

export default async function DashboardValenPage() {
  return <DashboardClient variant="valen" />
}
