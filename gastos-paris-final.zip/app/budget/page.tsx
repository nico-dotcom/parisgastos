import BudgetPageClient from './budget-page-client'

export default function BudgetPage() {
  return <BudgetPageClient />
}
